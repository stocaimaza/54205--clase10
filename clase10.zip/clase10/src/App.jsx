import React from 'react'
//import Eventos from './componentes/Eventos/Eventos'
//import Formulario from './componentes/Formulario/Formulario'
import Escuchadores from './componentes/Escuchadores/Escuchadores'
import Automatico from './componentes/Automatico/Automatico'

const App = () => {
  return (
    <div>
      {/* <Eventos/>
      <Formulario/> */}
      <Escuchadores/>
      <Automatico/>
    </div>
  )
}

export default App