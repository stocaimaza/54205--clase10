import { useState, useEffect } from "react";

const Automatico = () => {
    const [mostrarMensaje, setMostrarMensaje] = useState(false);

    useEffect(() => {
        let tiempoEsperaId = null;

        const reiniciarTemporizador = () => {
            clearTimeout(tiempoEsperaId);
            tiempoEsperaId = setTimeout(() => {
                setMostrarMensaje(true);
            }, 5000) //Tiempo en milisegundos (5 segundos en este caso)
        }

        const manejarActividadUsuario = () => {
            reiniciarTemporizador();
        }

        window.addEventListener("mousemove", manejarActividadUsuario);
        window.addEventListener("keydown", manejarActividadUsuario);

        reiniciarTemporizador();

        return () => {
            window.removeEventListener("mousemove", manejarActividadUsuario);
            window.removeEventListener("keydown", manejarActividadUsuario);
            clearTimeout(tiempoEsperaId);
        }

    }, [])

    const seguirMirando = () => {
        setMostrarMensaje(false);
    }


    return (
        <div>
            {
                mostrarMensaje && (
                    <div>
                        <p>¿Sigues ahí?</p>
                        <button onClick={seguirMirando}> Seguir Mirando </button>
                    </div>
                )
            }

            <h1>Contenido de Netflix</h1>

            <p>Tu pelicula o serie favorita</p>

        </div>
    )
}

export default Automatico