//podemos utilizar también los "event listeners"
//Trabajando con el objeto window. 
//Este objeto global representa a la ventana del navegador. 

import { useEffect } from "react"

const Escuchadores = () => {
    //Llamamos al objeto window y el método addEventListener

    window.addEventListener("resize", ()=> console.log("Cambiaste el tamaño de la pantalla"))

    //Lo correcto seria manejarlo en un useEffect: 

    useEffect( ()=> {
        function click() {
            console.log("click");
        }

        window.addEventListener("click", click);

        return () => {
            window.removeEventListener("click", click);
        }

    }, [])

  return (
    <div>Escuchadores</div>
  )
}

export default Escuchadores