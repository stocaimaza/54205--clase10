/* EVENTOS */

//1) Eventos manuales. 
//2) Eventos automáticos. (Ejemplo Netflix).

//Eventos más utilizados: 
//Click. 

//recordemos: 

// const titulo = document.getElementById("titulo");

// 1) titulo.addEventListener("nombreEvento", funcion);

// 2) titulo.onMouseMove = "propiedades del nodo"

//3) directamente en el html. 

import {useState} from 'react';
import './Eventos.css'

const Eventos = () => {
    const [input, setInput] = useState("");

    //Función para manejar los eventos. 
    //handler = manejador

    const manejadorClick = () => {
        console.log("Click");
    }

    const manejadorInput = (event) => {
      //Voy a trabajar con el objeto "event". 
      setInput(event.target.value);
      //La propiedad target es la referencia al objeto del DOM que disparo el evento. 
      console.log(input);
    }

  return (
    <div>
        <button onClick={ manejadorClick } > Haceme Click </button>

        <div className='caja'
          onMouseMove={()=> console.log("Nuevo evento")}
          onMouseEnter={()=>console.log("Entraste")}
          onMouseLeave={()=>console.log("Saliste")}
          >
        </div>

        <form>
          <h2> {input} </h2>
          <label htmlFor="campo"> Ingrese Texto </label>
          <input type="text" id='campo'
            onChange={manejadorInput}
            onKeyDown={()=> console.log("Presionaste una tecla")}
            onKeyUp={()=>console.log("Soltaste una tecla")}
            />


          {/*
            htmlFor = es igual al for que usamos en html 
            change = se dispara cuando el usuario cambia el valor del input.
            keydown = cuando presionamos una tecla. 
            keyup = cuando soltamos una tecla.
           */}
        </form>
    </div>
  )
}

export default Eventos