/* EVENTOS CON EL FORMULARIO */

//1) onSubmit

import { useState } from "react";

const Formulario = () => {
    //Creamos dos estados para los campos del formulario: 
    const [nombre, setNombre] = useState("");
    const [apellido, setApellido] = useState("");

    //Creamos una función manejadora del evento: 

    const handlerFormulario = (event) => {
        //Prevenimos la recarga de la página. 
        event.preventDefault();

        const nuevoCliente = {nombre, apellido};
        console.log(nuevoCliente);

        //Si queremos limpiar los campos después de agregar un nuevo objeto: 

        setNombre("");
        setApellido("");

        //event.target.value = "";


    }

  return (
    <form onSubmit={ handlerFormulario }>
        <label htmlFor="nombre"> Nombre </label>
        <input type="text" id="nombre" value={nombre} onChange={(e)=>setNombre(e.target.value)} />

        <label htmlFor="apellido"> Apellido </label>
        <input type="text" id="apellido" value={apellido} onChange={(e)=>setApellido(e.target.value)} />

        <button type="submit"> Enviar Datos </button>

        
    </form>
  )
}

export default Formulario